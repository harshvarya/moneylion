package com.moneylion.switches;

import com.moneylion.switches.dto.AccessDto;
import com.moneylion.switches.dto.FeatureDto;
import com.moneylion.switches.dto.SwitchDto;
import com.moneylion.switches.dto.UserDto;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
class SwitchApplicationTests {

    @LocalServerPort
    int definedPort;

    @Autowired
    RestTemplate restTemplate;

    private static final String BASE_URL = "http://localhost:%d/switches";

    /**
     * Test for fetching a Switch(user-feature-enable) using GET API call when specified email and featureName don't exist
     */
    @Test
    public void test1() {
        String url = String.format(BASE_URL, definedPort) + "/feature?email=E1&featureName=F1";
        ResponseEntity<AccessDto> result = restTemplate.getForEntity(url, AccessDto.class);
        Assert.assertNotNull("result mismatch : ", result.getBody());
        Assert.assertFalse("result mismatch : ", result.getBody().isCanAccess());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result.getStatusCode());
    }

    /**
     * Test for adding a Switch(user-feature-enable) using POST API call when specified email and featureName don't exist
     */
    @Test
    public void test2() {
        String url = String.format(BASE_URL, definedPort) + "/feature";

        SwitchDto dto = new SwitchDto();
        dto.setFeatureName("F1");
        dto.setEnable(true);
        dto.setEmail("E1");

        ResponseEntity<String> result = restTemplate.postForEntity(url, dto, String.class);
        Assert.assertEquals("result mismatch : ", null, result.getBody());
        Assert.assertEquals("result mismatch : ", HttpStatus.NOT_MODIFIED, result.getStatusCode());
    }

    /**
     * Test for adding a user and feature using POST calls
     */
    @Test
    public void test3() {

        String url1 = String.format(BASE_URL, definedPort) + "/user";
        UserDto uDto = new UserDto();
        uDto.setEmail("E1");

        ResponseEntity<String> result1 = restTemplate.postForEntity(url1, uDto, String.class);
        Assert.assertEquals("result mismatch : ", null, result1.getBody());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result1.getStatusCode());

        FeatureDto fDto = new FeatureDto();
        fDto.setFeatureName("F1");
        String url2 = String.format(BASE_URL, definedPort) + "/feature/add";
        result1 = restTemplate.postForEntity(url2, fDto, String.class);
        Assert.assertEquals("result mismatch : ", null, result1.getBody());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result1.getStatusCode());
    }

    /**
     * Test for adding/updating a Switch using POST call when specified user and feature exist
     */
    @Test
    public void test4() {
        String url = String.format(BASE_URL, definedPort) + "/feature";

        SwitchDto dto = new SwitchDto();
        dto.setFeatureName("F1");
        dto.setEnable(true);
        dto.setEmail("E1");

        ResponseEntity<String> result1 = restTemplate.postForEntity(url, dto, String.class);
        Assert.assertEquals("result mismatch : ", null, result1.getBody());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result1.getStatusCode());

        ResponseEntity<AccessDto> result2 = restTemplate.getForEntity(url + "?email=E1&featureName=F1", AccessDto.class);
        Assert.assertNotNull("result mismatch : ", result2.getBody());
        Assert.assertTrue("result mismatch : ", result2.getBody().isCanAccess());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result2.getStatusCode());

        dto.setEnable(false);

        result1 = restTemplate.postForEntity(url, dto, String.class);
        Assert.assertEquals("result mismatch : ", null, result1.getBody());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result1.getStatusCode());

        result2 = restTemplate.getForEntity(url + "?email=E1&featureName=F1", AccessDto.class);
        Assert.assertNotNull("result mismatch : ", result2.getBody());
        Assert.assertFalse("result mismatch : ", result2.getBody().isCanAccess());
        Assert.assertEquals("result mismatch : ", HttpStatus.OK, result2.getStatusCode());
    }
}
