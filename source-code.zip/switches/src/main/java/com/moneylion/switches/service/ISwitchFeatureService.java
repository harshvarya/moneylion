package com.moneylion.switches.service;

import com.moneylion.switches.dto.SwitchDto;

public interface ISwitchFeatureService {
    void addFeature(String featureName);
    boolean getAccess(String email, String featureName);
    boolean updateSwitch(SwitchDto dto);
}
