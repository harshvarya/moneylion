package com.moneylion.switches.dto;

public class AccessDto {
    private boolean canAccess;

    public AccessDto() {

    }

    public AccessDto(boolean canAccess) {
        this.canAccess = canAccess;
    }

    public boolean isCanAccess() {
        return canAccess;
    }

    public void setCanAccess(boolean canAccess) {
        this.canAccess = canAccess;
    }
}
