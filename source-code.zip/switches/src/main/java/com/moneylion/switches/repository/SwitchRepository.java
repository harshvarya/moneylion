package com.moneylion.switches.repository;

import com.moneylion.switches.model.Switch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SwitchRepository extends JpaRepository<Switch, Integer> {

    @Query("select s from Switch s inner join User u on u.id = s.userId inner join Feature f on s.featureId = f.id where u.email=?1 and f.name=?2")
    Switch findByEmailAndFeatureName(String email, String name);

}
