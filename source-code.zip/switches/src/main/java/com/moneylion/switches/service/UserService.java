package com.moneylion.switches.service;

import com.moneylion.switches.model.User;
import com.moneylion.switches.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service("userService")
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.SERIALIZABLE)
public class UserService implements IUserService {

    @Autowired
    UserRepository userRepository;

    @Override
    public void addUser(String em) {
        List<User> list = userRepository.findByEmail(em);
        if (Objects.isNull(list) || list.size() == 0) {
            User user = new User();
            user.setEmail(em);
            userRepository.save(user);
        }
    }
}
