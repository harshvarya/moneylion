package com.moneylion.switches.service;

import com.moneylion.switches.dto.SwitchDto;
import com.moneylion.switches.model.Feature;
import com.moneylion.switches.model.User;
import com.moneylion.switches.model.Switch;
import com.moneylion.switches.repository.FeatureRepository;
import com.moneylion.switches.repository.SwitchRepository;
import com.moneylion.switches.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service("switchFeatureService")
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.SERIALIZABLE)
public class SwitchFeatureService implements ISwitchFeatureService {

    @Autowired
    UserRepository userRepository;
    @Autowired
    FeatureRepository featureRepository;
    @Autowired
    SwitchRepository switchRepository;

    @Override
    public void addFeature(String featureName) {
        List<Feature> list = featureRepository.findByName(featureName);
        if (Objects.isNull(list) || list.size() == 0) {
            Feature feature = new Feature();
            feature.setName(featureName);
            featureRepository.save(feature);
        }
    }

    @Override
    public boolean getAccess(String email, String featureName) {
        Switch uf = switchRepository.findByEmailAndFeatureName(email, featureName);
        if (Objects.nonNull(uf)) {
            return uf.isAccess();
        }
        return false;
    }

    @Override
    public boolean updateSwitch(SwitchDto dto) {
        // update if exists
        Switch uf = switchRepository.findByEmailAndFeatureName(dto.getEmail(), dto.getFeatureName());
        if (Objects.nonNull(uf)) {
            uf.setAccess(dto.isEnable());
            switchRepository.save(uf);
            return true;
        }

        // create new one
        List<Feature> ftrList = featureRepository.findByName(dto.getFeatureName());
        Feature feature;
        if (Objects.nonNull(ftrList) && ftrList.size() > 0) {
            feature = ftrList.get(0);
        } else {
            return false;
        }
        List<User> usrList = userRepository.findByEmail(dto.getEmail());
        User user;
        if (Objects.nonNull(usrList) && usrList.size() > 0) {
            user = usrList.get(0);
        } else {
            return false;
        }

        Switch aSwitch = new Switch();
        aSwitch.setAccess(dto.isEnable());
        aSwitch.setUserId(user.getId());
        aSwitch.setFeatureId(feature.getId());
        aSwitch = switchRepository.save(aSwitch);
        if (aSwitch.getId() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
