package com.moneylion.switches.controller;

import com.moneylion.switches.dto.AccessDto;
import com.moneylion.switches.dto.FeatureDto;
import com.moneylion.switches.dto.SwitchDto;
import com.moneylion.switches.service.ISwitchFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/feature")
public class SwitchFeatureController {

    @Autowired
    ISwitchFeatureService switchFeatureService;

    @GetMapping
    public AccessDto getAccess(@RequestParam("email") String email,
                               @RequestParam("featureName") String featureName) {
        boolean access = switchFeatureService.getAccess(email, featureName);
        return new AccessDto(access);
    }

    @PostMapping
    public ResponseEntity<String> updateSwitch(@RequestBody SwitchDto dto) {
        HttpStatus status = HttpStatus.OK;
        try {
            boolean success = switchFeatureService.updateSwitch(dto);
            if(!success) {
                status = HttpStatus.NOT_MODIFIED;
            }
        } catch(Exception ex) {
            status = HttpStatus.NOT_MODIFIED;
        }
        return new ResponseEntity<String>(status);
    }

    @PostMapping("/add")
    public ResponseEntity<String> addFeature(@RequestBody FeatureDto dto) {
        HttpStatus status = HttpStatus.OK;
        try {
            switchFeatureService.addFeature(dto.getFeatureName());
        } catch(Exception ex) {
            status = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(status);
    }
}
