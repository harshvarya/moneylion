package com.moneylion.switches.controller;

import com.moneylion.switches.dto.UserDto;
import com.moneylion.switches.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    IUserService userService;

    @PostMapping
    public ResponseEntity<String> addUser(@RequestBody UserDto dto) {
        HttpStatus status = HttpStatus.OK;
        try {
            userService.addUser(dto.getEmail());
        } catch(Exception ex) {
            status = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(status);
    }
}
