package com.moneylion.switches.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FeatureDto {

    @JsonProperty(required = true)
    private String featureName;

    public FeatureDto() {
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }
}
