package com.moneylion.switches.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SwitchDto {

    @JsonProperty(required = true)
    private String email;
    @JsonProperty(required = true)
    private String featureName;
    @JsonProperty(required = true)
    private boolean enable;

    public SwitchDto() {
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }
}
