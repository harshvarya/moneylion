package com.moneylion.switches.service;

public interface IUserService {
    void addUser(String email);
}
